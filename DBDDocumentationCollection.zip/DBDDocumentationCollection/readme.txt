
Unpack files into deepbluedata project directory ./data

If you already have a DBDDocumentationCollection and want to replace it, rename it, or edit the file:
./data/DBDDocumentationCollection/dbd_doc_collection_build_from_data_dir.yml
and rename the collection to title DBDDocumentationCollection to something different. (Lines 57 and 58)
Once the import script is run, you can swap the new and collections by editing their names in DBD.

If you want to only add new files to your current DBDDocumentation, then run import script. It will skip existing works
and files.

Run the import script:

bundle exec rake deepblue:build[./data/DBDDocumentationCollection/dbd_doc_collection_build_from_data_dir.yml,'{"verbose":true\,"ingester":"fritx@umich.edu"}']

Exporting the current state of the documentation can be done using the following command with id
of the DBDDocumentation (replace 'collection_id') (ensuring that the target direction exists):

mkdir ./data/DBDDoc/

bundle exec rake deepblue:yaml_populate_from_collection['collection_id','{"target_dir":"./data/DBDDoc"\,"export_files":true\,"mode":"build"}']
